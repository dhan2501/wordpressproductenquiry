<?php get_header(); ?>

<div class="search-results">
    <h2>Search Resultsddddddddddddddd for: <?php echo get_search_query(); ?></h2>

    <?php if (have_posts()) : ?>
        <ul>
            <?php while (have_posts()) : the_post(); ?>
                <li>
                    <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                    <p><?php the_excerpt(); ?></p>
                </li>
            <?php endwhile; ?>
        </ul>

        <!-- Pagination (optional) -->
        <div class="pagination">
            <?php echo paginate_links(); ?>
        </div>
    <?php else : ?>
        <p>No results found.</p>
    <?php endif; ?>
</div>
<form action="/" method="get">
	<label for="search">Search in <?php echo home_url( '/' ); ?></label>
	<input type="text" name="s" id="search" value="<?php the_search_query(); ?>" />
	<input type="image" alt="Search" src="<?php bloginfo( 'template_url' ); ?>/images/search.png" />
</form>
<?php get_footer(); ?>
